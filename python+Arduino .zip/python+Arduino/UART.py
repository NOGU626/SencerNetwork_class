import serial
import ambient
if __name__ == '__main__':
    ser = serial.Serial("/dev/tty.usbmodem144101", 115200)
    data = []
    flag = False
    while True:
        message = ser.readline().decode('utf-8').replace('\n','')
        if(message == 'START'):
            flag = True
        elif(message == 'END'):
            flag = False
            ambi = ambient.Ambient(14911, "c8592a4c4c4536d5")
            r = ambi.send({"d1": data[0], "d2": data[1], "d3": data[2]})
            print(r)
            data = []
        else:
            if(flag):
                print(message)
                data.append(message)
            